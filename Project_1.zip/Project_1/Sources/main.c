/*
 * HCS12 Joystick Controller - CALIBRATED 
 * 
 * Calibration values from testing:
 *   X center: ~550 (showed 5-6)
 *   Y center: ~150 (showed 1)
 * 
 * SW (Push Button) on PA0 = Backwards command
 */
#include <hidef.h>
#include "derivative.h"

const unsigned char SEG[] = {0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};

/*
 * CALIBRATION - Based on your actual readings
 */
#define CENTER_X     550
#define CENTER_Y     150    // Your Y center is LOW (~100-200)
#define DEADZONE_X   200
#define DEADZONE_Y   150    // Large deadzone for Y

// X thresholds
#define LEFT_TH      (CENTER_X - DEADZONE_X)   // ~350
#define RIGHT_TH     (CENTER_X + DEADZONE_X)   // ~750

// Y thresholds  
#define UP_TH        50     // Below this = Backward (probably broken)
#define DOWN_TH      350    // Above this = Forward

void delay_ms(unsigned int ms) {
    unsigned int i, j;
    for(i = 0; i < ms; i++)
        for(j = 0; j < 1000; j++)
            __asm nop;
}

void seg_show(unsigned char n) {
    PTH = ~SEG[n % 10];
}

void adc_init(void) {
    ATD1CTL2 = 0x80;
    delay_ms(2);
    ATD1CTL3 = 0x00;
    ATD1CTL4 = 0x85;
}

unsigned int adc_read(unsigned char ch) {
    ATD1CTL5 = 0x20 | (ch & 0x0F);
    while(!(ATD1STAT0 & 0x80));
    return ATD1DR0 & 0x03FF;
}

void serial_init(void) {
    SCI1BDH = 0;
    SCI1BDL = 26;
    SCI1CR1 = 0x00;
    SCI1CR2 = 0x08;
}

void serial_send(char c) {
    while(!(SCI1SR1 & 0x80));
    SCI1DRL = c;
}

unsigned char button_pressed(void) {
    // Returns 1 if SW (PA0) is pressed (active-low with pull-up)
    return !(PORTA & 0x01);
}

char get_command(unsigned int x, unsigned int y) {
    // Check push button FIRST - highest priority for backwards
    if(button_pressed()) return 'B';
    
    // X axis (left/right)
    if(x <= LEFT_TH)  return 'L';
    if(x >= RIGHT_TH) return 'R';
    
    // Y axis (forward only now, backwards handled by button)
    if(y >= DOWN_TH)  return 'F';
    
    return 'S';  // In deadzone = Stop
}

void main(void) {
    unsigned int x, y;
    char cmd, last_cmd = 'X';  // X = invalid, forces first send
    
    DDRH = 0xFF;           // Port H as output (7-seg)
    DDRA &= ~0x01;         // PA0 as input (push button SW)
    PUCR |= 0x01;          // Enable pull-up on Port A (PUPAE bit)
    
    seg_show(8);  // Startup
    
    adc_init();
    serial_init();
    
    delay_ms(500);
    
    // Send initial stop
    serial_send('S');
    seg_show(0);
    
    for(;;) {
        x = adc_read(8);
        y = adc_read(9);
        
        cmd = get_command(x, y);
        
        // Always send command (Arduino needs continuous signal)
        serial_send(cmd);
        
        // Update display only when changed
        if(cmd != last_cmd) {
            last_cmd = cmd;
            
            // Update display: 0=Stop, 1=Left, 2=Right, 3=Back, 4=Forward
            switch(cmd) {
                case 'S': seg_show(0); break;
                case 'L': seg_show(1); break;
                case 'R': seg_show(2); break;
                case 'B': seg_show(3); break;
                case 'F': seg_show(4); break;
            }
        }
        
        delay_ms(50);
    }
}